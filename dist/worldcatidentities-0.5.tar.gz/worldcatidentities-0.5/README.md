# Worldcat Identities [![Build Status](https://travis-ci.org/Wences91/worldcatidentities.svg?branch=master)](https://travis-ci.org/Wences91/worldcatidentities)
Python package that recovers authorities data from OCLC's WorldCat Identities API

## Installation
```
$ pip install worldcatidentities
```
or
```
$ git clone https://github.com/Wences91/worldcatidentities.git
$ python setup.py install
```
