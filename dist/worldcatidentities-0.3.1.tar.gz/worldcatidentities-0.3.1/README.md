# worldcatidentities
Python package that recovers authorities data from OCLC's WorldCat Identities API
